import type React from "react"
import type { Metadata } from "next"
import { Inter, Orbitron, Space_Mono } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })
const orbitron = Orbitron({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
  variable: "--font-orbitron",
})
const spaceMono = Space_Mono({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-space-mono",
})

export const metadata: Metadata = {
  title: "TakeYourSoul ($SOUL) | The Darkness Is Coming",
  description:
    "A new force awakens from the shadows. This isn't just a memecoin... it's a movement. It's a warning. You don't own Soul — Soul owns YOU.",
  icons: {
    icon: [
      {
        url: "/images/soul-logo.jpeg",
        type: "image/jpeg",
      },
    ],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} ${orbitron.variable} ${spaceMono.variable}`}>{children}</body>
    </html>
  )
}
