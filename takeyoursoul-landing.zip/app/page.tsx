"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import {
  Skull,
  Flame,
  ChevronDown,
  ExternalLink,
  Lock,
  Zap,
  Users,
  TrendingUp,
  BarChart3,
  MessageSquare,
  Twitter,
  Send,
} from "lucide-react"

import CountdownTimer from "@/components/countdown-timer"
import GlitchText from "@/components/glitch-text"
import NeonButton from "@/components/neon-button"
import RoadmapItem from "@/components/roadmap-item"
import NftCard from "@/components/nft-card"
import StrategyCard from "@/components/strategy-card"
import TokenomicsCard from "@/components/tokenomics-card"
import Navbar from "@/components/navbar"

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white overflow-hidden">
      <div className="fixed inset-0 bg-[url('/noise.png')] opacity-5 pointer-events-none z-10"></div>

      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 to-red-900/10 z-0"></div>
        <div className="absolute inset-0 bg-[url('/grid.png')] bg-center opacity-10 z-0"></div>

        {/* Hero background image */}
        <div className="absolute inset-0 z-0">
          <Image
            src="/images/hero-hand.jpeg"
            alt="Hand reaching for the moon"
            fill
            className="object-cover opacity-40"
            priority
          />
        </div>

        {/* Animated glowing orbs */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-[#7b1fa2] opacity-20 blur-[100px] animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-72 h-72 rounded-full bg-[#ff1744] opacity-20 blur-[100px] animate-pulse delay-1000"></div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5 }}
          className="container mx-auto text-center relative z-20"
        >
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <GlitchText className="text-4xl md:text-6xl lg:text-7xl font-orbitron font-bold mb-4">
              ☠️ The Darkness Is Coming... ☠️
            </GlitchText>
          </motion.div>

          <motion.p
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl lg:text-2xl mb-8 font-space-mono text-gray-300"
          >
            <span className="text-[#ff1744] font-bold">SOUL</span> goes LIVE on Solana ⛓️ 18-05 — No rules. No mercy.
            Only massive gains.
          </motion.p>

          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
          >
            <NeonButton href="https://t.me/Takeyoursoulgroup" color="purple" icon={<Send className="w-4 h-4 mr-2" />}>
              Join Telegram
            </NeonButton>
            <NeonButton href="https://x.com/TakeYoursoul01" color="red" icon={<Twitter className="w-4 h-4 mr-2" />}>
              Follow on X
            </NeonButton>
          </motion.div>

          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <CountdownTimer targetDate="2025-05-18T00:00:00" />
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          transition={{ duration: 1, delay: 1.5 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 cursor-pointer animate-bounce"
        >
          <ChevronDown className="w-8 h-8 text-white" />
        </motion.div>
      </section>

      {/* Logo Showcase */}
      <section className="py-16 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black to-purple-900/10 z-0"></div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-4xl relative z-10 text-center"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative w-48 h-48 md:w-64 md:h-64 mx-auto mb-8"
          >
            <Image src="/images/soul-logo.jpeg" alt="SOUL Logo" fill className="object-contain" />
            <motion.div
              className="absolute inset-0"
              animate={{
                boxShadow: [
                  "0 0 10px 0px rgba(123,31,162,0.5)",
                  "0 0 20px 5px rgba(255,23,68,0.5)",
                  "0 0 10px 0px rgba(123,31,162,0.5)",
                ],
              }}
              transition={{
                duration: 3,
                repeat: Number.POSITIVE_INFINITY,
                repeatType: "reverse",
              }}
            />
          </motion.div>

          <motion.h2
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-3xl md:text-4xl font-orbitron font-bold mb-4"
          >
            <span className="text-[#ff1744]">TAKE YOUR SOUL</span>
          </motion.h2>

          <motion.p
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="text-xl font-space-mono text-gray-300 max-w-2xl mx-auto"
          >
            The most terrifying memecoin on Solana. Your soul is no longer yours to keep.
          </motion.p>
        </motion.div>
      </section>

      {/* About Soul Section */}
      <section id="about" className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/10 to-red-900/5 z-0"></div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-4xl relative z-10"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-2 inline-block relative">
              <span className="relative z-10">
                About <span className="text-[#ff1744]">SOUL</span>
              </span>
              <span className="absolute inset-0 bg-[#ff1744] blur-md opacity-20 z-0"></span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mx-auto mt-4"></div>
          </div>

          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-8 shadow-lg relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-40 h-40 bg-[#7b1fa2] opacity-20 blur-[50px] rounded-full"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#ff1744] opacity-20 blur-[50px] rounded-full"></div>

            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <p className="text-xl md:text-2xl font-space-mono leading-relaxed text-gray-300 relative z-10">
                  A new force awakens from the shadows. This isn't just a memecoin... it's a movement. It's a warning.
                  <span className="block mt-4 text-white font-bold italic">
                    You don't own Soul — <span className="text-[#ff1744]">Soul owns YOU.</span>
                  </span>
                </p>

                <div className="flex justify-center mt-8 gap-8">
                  <motion.div
                    animate={{
                      opacity: [0.5, 1, 0.5],
                      scale: [0.98, 1.02, 0.98],
                    }}
                    transition={{
                      repeat: Number.POSITIVE_INFINITY,
                      duration: 3,
                      ease: "easeInOut",
                    }}
                  >
                    <Skull className="w-12 h-12 text-[#ff1744]" />
                  </motion.div>
                  <motion.div
                    animate={{
                      opacity: [0.5, 1, 0.5],
                      scale: [0.98, 1.02, 0.98],
                    }}
                    transition={{
                      repeat: Number.POSITIVE_INFINITY,
                      duration: 3,
                      delay: 1,
                      ease: "easeInOut",
                    }}
                  >
                    <Flame className="w-12 h-12 text-[#7b1fa2]" />
                  </motion.div>
                </div>
              </div>
              <div className="relative h-64 md:h-full min-h-[300px] rounded-lg overflow-hidden">
                <Image src="/images/silhouette.jpeg" alt="Mysterious figure" fill className="object-cover rounded-lg" />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Launch Highlights */}
      <section id="tokenomics" className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black to-purple-900/10 z-0"></div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-6xl relative z-10"
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-2 inline-block relative">
              <span className="relative z-10">Launch Highlights</span>
              <span className="absolute inset-0 bg-[#7b1fa2] blur-md opacity-20 z-0"></span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mx-auto mt-4"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="col-span-1"
            >
              <div className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-6 h-full flex flex-col items-center text-center hover:border-[#7b1fa2]/50 transition-all duration-300 group">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#7b1fa2] to-[#ff1744] flex items-center justify-center mb-4">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-orbitron font-bold mb-2">Launch Date</h3>
                <p className="text-gray-300 font-space-mono">18-05-2025</p>
                <div className="w-0 group-hover:w-full h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mt-4 transition-all duration-500"></div>
              </div>
            </motion.div>

            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="col-span-1"
            >
              <div className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-6 h-full flex flex-col items-center text-center hover:border-[#7b1fa2]/50 transition-all duration-300 group">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#7b1fa2] to-[#ff1744] flex items-center justify-center mb-4">
                  <ExternalLink className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-orbitron font-bold mb-2">Chain</h3>
                <p className="text-gray-300 font-space-mono">Solana</p>
                <div className="w-0 group-hover:w-full h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mt-4 transition-all duration-500"></div>
              </div>
            </motion.div>

            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="col-span-1"
            >
              <div className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-6 h-full flex flex-col items-center text-center hover:border-[#7b1fa2]/50 transition-all duration-300 group">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#7b1fa2] to-[#ff1744] flex items-center justify-center mb-4">
                  <Skull className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-orbitron font-bold mb-2">Ticker</h3>
                <p className="text-gray-300 font-space-mono">$SOUL</p>
                <div className="w-0 group-hover:w-full h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mt-4 transition-all duration-500"></div>
              </div>
            </motion.div>

            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="col-span-1"
            >
              <div className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-6 h-full flex flex-col items-center text-center hover:border-[#7b1fa2]/50 transition-all duration-300 group">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#7b1fa2] to-[#ff1744] flex items-center justify-center mb-4">
                  <BarChart3 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-orbitron font-bold mb-2">Tokenomics</h3>
                <Link href="#tokenomics-details" className="text-[#ff1744] underline font-space-mono">
                  View Details
                </Link>
                <div className="w-0 group-hover:w-full h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mt-4 transition-all duration-500"></div>
              </div>
            </motion.div>
          </div>

          <div id="tokenomics-details" className="mt-16">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <TokenomicsCard
                title="4% Liquidity"
                description="4% of every transaction goes to liquidity"
                icon={<TrendingUp className="w-8 h-8 text-white" />}
                delay={0.1}
              />
              <TokenomicsCard
                title="Liquidity Locked"
                description="Liquidity locked & 100% burned"
                icon={<Lock className="w-8 h-8 text-white" />}
                delay={0.2}
              />
              <TokenomicsCard
                title="Team Allocation"
                description="Team holds 10%"
                icon={<Users className="w-8 h-8 text-white" />}
                delay={0.3}
              />
            </div>
          </div>
        </motion.div>
      </section>

      {/* NFT Promo Section */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/10 to-red-900/10 z-0"></div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-6xl relative z-10"
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-2 inline-block relative">
              <span className="relative z-10">Grab a FREE NFT Worth $150–$300</span>
              <span className="absolute inset-0 bg-[#ff1744] blur-md opacity-20 z-0"></span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mx-auto mt-4"></div>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto mt-6 font-space-mono">
              Early adopters on launch day will receive exclusive NFTs with real value. Join us on day one to claim
              yours.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <NftCard title="Soul Collector" value="$150" delay={0.1} imageSrc="/images/skull-tophat.jpeg" />
            <NftCard title="Soul Keeper" value="$200" delay={0.2} imageSrc="/images/neon-skull.jpeg" />
            <NftCard title="Soul Master" value="$300" delay={0.3} imageSrc="/images/soul-takers.jpeg" />
          </div>
        </motion.div>
      </section>

      {/* Launch Strategy */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black to-purple-900/10 z-0"></div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-6xl relative z-10"
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-2 inline-block relative">
              <span className="relative z-10">Launch Strategy</span>
              <span className="absolute inset-0 bg-[#7b1fa2] blur-md opacity-20 z-0"></span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mx-auto mt-4"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <StrategyCard
              title="Influencer Drops"
              description="Strategic partnerships with key crypto influencers to maximize reach"
              icon={<Users className="w-8 h-8 text-white" />}
              delay={0.1}
            />
            <StrategyCard
              title="DEX Ads"
              description="Premium placement on top decentralized exchanges"
              icon={<ExternalLink className="w-8 h-8 text-white" />}
              delay={0.2}
            />
            <StrategyCard
              title="Token Boosts"
              description="Strategic token burns and buybacks to support price action"
              icon={<TrendingUp className="w-8 h-8 text-white" />}
              delay={0.3}
            />
            <StrategyCard
              title="Community Growth"
              description="Aggressive community building with exclusive rewards"
              icon={<MessageSquare className="w-8 h-8 text-white" />}
              delay={0.4}
            />
          </div>
        </motion.div>
      </section>

      {/* Roadmap */}
      <section id="roadmap" className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/10 to-red-900/10 z-0"></div>

        {/* Background image with overlay */}
        <div className="absolute inset-0 z-0 opacity-20">
          <Image src="/images/dead-tree.jpeg" alt="Dead tree" fill className="object-cover" />
          <div className="absolute inset-0 bg-black/70"></div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-4xl relative z-10"
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-2 inline-block relative">
              <span className="relative z-10">Roadmap – "Lose Your Soul"</span>
              <span className="absolute inset-0 bg-[#ff1744] blur-md opacity-20 z-0"></span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mx-auto mt-4"></div>
          </div>

          <div className="space-y-12">
            <RoadmapItem
              phase="Phase 1: The Awakening"
              items={[
                "Initial token launch on Solana",
                "Community building and social media presence",
                "First NFT drop for early adopters",
                "Listing on major DEXs",
              ]}
              delay={0.1}
            />

            <RoadmapItem
              phase="Phase 2: The Possession"
              items={[
                "Major marketing campaigns",
                "Strategic partnerships with other projects",
                "CEX listings",
                "Community governance implementation",
              ]}
              delay={0.2}
            />

            <RoadmapItem
              phase="Phase 3: The Rise"
              items={[
                "Ecosystem expansion",
                "Cross-chain integration",
                "Advanced utility development",
                "Global domination",
              ]}
              delay={0.3}
            />
          </div>
        </motion.div>
      </section>

      {/* Countdown Timer Section */}
      <section className="py-20 px-4 relative bg-black">
        <div className="absolute inset-0 bg-[url('/grid.png')] bg-center opacity-10 z-0"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 to-red-900/20 z-0"></div>

        {/* Background image with overlay */}
        <div className="absolute inset-0 z-0 opacity-30">
          <Image
            src="/images/take-your-soul-logo.jpeg"
            alt="Take Your Soul Logo"
            fill
            className="object-cover object-center"
          />
          <div className="absolute inset-0 bg-black/70"></div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-4xl relative z-10 text-center"
        >
          <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-8 inline-block relative">
            <span className="relative z-10">Time Remaining Until Launch</span>
            <span className="absolute inset-0 bg-[#7b1fa2] blur-md opacity-20 z-0"></span>
          </h2>

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <CountdownTimer targetDate="2025-05-18T00:00:00" large />
          </motion.div>
        </motion.div>
      </section>

      {/* Join The Movement */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black to-purple-900/20 z-0"></div>

        {/* Background image with overlay */}
        <div className="absolute inset-0 z-0 opacity-10">
          <Image src="/images/matrix.jpeg" alt="Matrix background" fill className="object-cover" />
          <div className="absolute inset-0 bg-black/70"></div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="container mx-auto max-w-4xl relative z-10"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-2 inline-block relative">
              <span className="relative z-10">Join The Movement</span>
              <span className="absolute inset-0 bg-[#ff1744] blur-md opacity-20 z-0"></span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] mx-auto mt-4"></div>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto mt-6 font-space-mono">
              Follow us, tag us, spread the word. The darkness is coming.
            </p>
          </div>

          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-6 justify-center mb-12"
          >
            <NeonButton
              href="https://t.me/Takeyoursoulgroup"
              color="purple"
              icon={<Send className="w-4 h-4 mr-2" />}
              large
            >
              Join Telegram
            </NeonButton>
            <NeonButton
              href="https://x.com/TakeYoursoul01"
              color="red"
              icon={<Twitter className="w-4 h-4 mr-2" />}
              large
            >
              Follow on X
            </NeonButton>
          </motion.div>

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-black/60 backdrop-blur-sm border border-white/10 rounded-lg p-8 text-center"
          >
            <p className="text-xl font-space-mono text-gray-300 mb-4">Use our hashtags:</p>
            <div className="flex flex-wrap justify-center gap-3">
              <span className="px-3 py-1 bg-[#7b1fa2]/20 border border-[#7b1fa2]/30 rounded-full text-white font-space-mono text-sm">
                #TakeYourSoul
              </span>
              <span className="px-3 py-1 bg-[#7b1fa2]/20 border border-[#7b1fa2]/30 rounded-full text-white font-space-mono text-sm">
                #SoulOnSolana
              </span>
              <span className="px-3 py-1 bg-[#7b1fa2]/20 border border-[#7b1fa2]/30 rounded-full text-white font-space-mono text-sm">
                #DarkestGemAlive
              </span>
              <span className="px-3 py-1 bg-[#7b1fa2]/20 border border-[#7b1fa2]/30 rounded-full text-white font-space-mono text-sm">
                #CryptoWarning
              </span>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 relative border-t border-white/10">
        <div className="absolute inset-0 bg-black z-0"></div>

        <div className="container mx-auto max-w-6xl relative z-10">
          <div className="flex flex-col items-center justify-center text-center">
            <GlitchText className="text-xl md:text-2xl font-orbitron font-bold mb-6">
              You don't own Soul — Soul owns YOU.
            </GlitchText>

            <div className="flex gap-6 mb-8">
              <Link href="https://t.me/Takeyoursoulgroup" className="text-white hover:text-[#7b1fa2] transition-colors">
                <Send className="w-6 h-6" />
              </Link>
              <Link href="https://x.com/TakeYoursoul01" className="text-white hover:text-[#ff1744] transition-colors">
                <Twitter className="w-6 h-6" />
              </Link>
            </div>

            <p className="text-sm text-gray-500 font-space-mono">© 2025 TakeYourSoul. All rights surrendered.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
