"use client"

import { motion } from "framer-motion"
import Image from "next/image"

interface NftCardProps {
  title: string
  value: string
  delay: number
  imageSrc?: string
}

export default function NftCard({ title, value, delay, imageSrc }: NftCardProps) {
  return (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
      whileHover={{ y: -10, transition: { duration: 0.3 } }}
      className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-6 relative overflow-hidden group"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-[#7b1fa2]/20 to-[#ff1744]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>

      <div className="relative z-10">
        <div className="w-full aspect-square relative mb-4 overflow-hidden rounded-lg">
          <div className="absolute inset-0 bg-gradient-to-br from-[#7b1fa2] to-[#ff1744] opacity-30"></div>
          <Image
            src={imageSrc || "/placeholder.svg?height=300&width=300"}
            alt={title}
            width={300}
            height={300}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-white font-orbitron text-xl font-bold">{title}</span>
          </div>

          <motion.div
            className="absolute top-0 left-0 w-full h-full bg-white/10"
            animate={{
              y: ["100%", "-100%"],
              x: ["100%", "-100%"],
            }}
            transition={{
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "loop",
              duration: 3,
              ease: "linear",
            }}
            style={{
              clipPath: "polygon(0 0, 100% 0, 100% 5px, 0 5px)",
            }}
          />
        </div>

        <h3 className="text-xl font-orbitron font-bold mb-2 text-white">{title}</h3>
        <div className="flex justify-between items-center">
          <span className="text-gray-300 font-space-mono">Value:</span>
          <span className="text-[#ff1744] font-orbitron font-bold">{value}</span>
        </div>

        <div className="mt-4 w-full h-1 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
      </div>
    </motion.div>
  )
}
