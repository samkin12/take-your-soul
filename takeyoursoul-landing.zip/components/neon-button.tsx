"use client"

import type React from "react"

import Link from "next/link"
import { motion } from "framer-motion"

interface NeonButtonProps {
  href: string
  children: React.ReactNode
  color: "purple" | "red"
  icon?: React.ReactNode
  large?: boolean
}

export default function NeonButton({ href, children, color, icon, large = false }: NeonButtonProps) {
  const colorClasses = {
    purple: {
      bg: "bg-[#7b1fa2]",
      border: "border-[#7b1fa2]",
      shadow: "shadow-[0_0_15px_rgba(123,31,162,0.5)]",
      hoverShadow: "hover:shadow-[0_0_25px_rgba(123,31,162,0.7)]",
    },
    red: {
      bg: "bg-[#ff1744]",
      border: "border-[#ff1744]",
      shadow: "shadow-[0_0_15px_rgba(255,23,68,0.5)]",
      hoverShadow: "hover:shadow-[0_0_25px_rgba(255,23,68,0.7)]",
    },
  }

  const sizeClasses = large ? "px-8 py-4 text-lg" : "px-6 py-3 text-base"

  return (
    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }}>
      <Link
        href={href}
        className={`
          inline-flex items-center justify-center
          ${sizeClasses}
          ${colorClasses[color].bg}
          ${colorClasses[color].border}
          ${colorClasses[color].shadow}
          ${colorClasses[color].hoverShadow}
          border-2
          rounded-md
          font-orbitron font-bold
          text-white
          transition-all duration-300
          hover:brightness-110
          relative
          overflow-hidden
          z-10
        `}
        target="_blank"
        rel="noopener noreferrer"
      >
        <span className="relative z-10 flex items-center">
          {icon}
          {children}
        </span>
        <span className="absolute inset-0 bg-white/20 z-0 opacity-0 hover:opacity-20 transition-opacity duration-300"></span>
      </Link>
    </motion.div>
  )
}
