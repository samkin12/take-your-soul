"use client"

import { motion } from "framer-motion"
import { Check } from "lucide-react"

interface RoadmapItemProps {
  phase: string
  items: string[]
  delay: number
}

export default function RoadmapItem({ phase, items, delay }: RoadmapItemProps) {
  return (
    <motion.div
      initial={{ x: -50, opacity: 0 }}
      whileInView={{ x: 0, opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
      className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-6 relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-40 h-40 bg-[#7b1fa2] opacity-10 blur-[50px] rounded-full"></div>

      <h3 className="text-2xl font-orbitron font-bold mb-4 text-white">{phase}</h3>

      <ul className="space-y-3">
        {items.map((item, index) => (
          <motion.li
            key={index}
            initial={{ x: -20, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: delay + index * 0.1 }}
            className="flex items-start gap-3"
          >
            <span className="mt-1 flex-shrink-0 w-5 h-5 rounded-full bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] flex items-center justify-center">
              <Check className="w-3 h-3 text-white" />
            </span>
            <span className="text-gray-300 font-space-mono">{item}</span>
          </motion.li>
        ))}
      </ul>
    </motion.div>
  )
}
