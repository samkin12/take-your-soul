"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface GlitchTextProps {
  children: React.ReactNode
  className?: string
}

export default function GlitchText({ children, className = "" }: GlitchTextProps) {
  const [isGlitching, setIsGlitching] = useState(false)

  useEffect(() => {
    const glitchInterval = setInterval(() => {
      setIsGlitching(true)
      setTimeout(() => setIsGlitching(false), 300)
    }, 5000)

    return () => clearInterval(glitchInterval)
  }, [])

  return (
    <div className={`relative inline-block ${className}`}>
      <motion.span
        animate={{
          x: isGlitching ? [0, -3, 5, -2, 0] : 0,
          opacity: isGlitching ? [1, 0.7, 0.9, 0.8, 1] : 1,
        }}
        transition={{ duration: 0.3 }}
      >
        {children}
      </motion.span>

      {isGlitching && (
        <>
          <span
            className="absolute top-0 left-0 w-full h-full text-[#ff1744] opacity-90 mix-blend-screen"
            style={{ clipPath: "polygon(0 15%, 100% 15%, 100% 30%, 0 30%)" }}
          >
            {children}
          </span>
          <span
            className="absolute top-0 left-0 w-full h-full text-[#7b1fa2] opacity-90 mix-blend-screen"
            style={{ clipPath: "polygon(0 60%, 100% 60%, 100% 75%, 0 75%)" }}
          >
            {children}
          </span>
          <span
            className="absolute top-0 left-0 w-full h-full text-white opacity-70 mix-blend-overlay"
            style={{ clipPath: "polygon(0 40%, 100% 40%, 100% 45%, 0 45%)" }}
          >
            {children}
          </span>
        </>
      )}
    </div>
  )
}
