"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import Image from "next/image"

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "bg-black/80 backdrop-blur-md shadow-lg" : "bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="relative w-10 h-10 overflow-hidden">
              <Image src="/images/soul-logo.jpeg" alt="SOUL Logo" width={40} height={40} className="object-contain" />
            </div>
            <span className="font-orbitron font-bold text-white text-xl">$SOUL</span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <NavLink href="#about">About</NavLink>
            <NavLink href="#tokenomics">Tokenomics</NavLink>
            <NavLink href="#roadmap">Roadmap</NavLink>
            <Link
              href="https://t.me/Takeyoursoulgroup"
              className="px-4 py-2 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] rounded-md font-orbitron font-bold text-white hover:brightness-110 transition-all"
              target="_blank"
              rel="noopener noreferrer"
            >
              Join Telegram
            </Link>
          </div>

          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(true)}>
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </motion.header>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col"
          >
            <div className="container mx-auto px-4 py-4 flex items-center justify-between">
              <Link href="/" className="flex items-center gap-2">
                <div className="relative w-10 h-10 overflow-hidden">
                  <Image
                    src="/images/soul-logo.jpeg"
                    alt="SOUL Logo"
                    width={40}
                    height={40}
                    className="object-contain"
                  />
                </div>
                <span className="font-orbitron font-bold text-white text-xl">$SOUL</span>
              </Link>

              <button className="text-white" onClick={() => setIsMenuOpen(false)}>
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex flex-col items-center justify-center flex-1 gap-8">
              <MobileNavLink href="#about" onClick={() => setIsMenuOpen(false)}>
                About
              </MobileNavLink>
              <MobileNavLink href="#tokenomics" onClick={() => setIsMenuOpen(false)}>
                Tokenomics
              </MobileNavLink>
              <MobileNavLink href="#roadmap" onClick={() => setIsMenuOpen(false)}>
                Roadmap
              </MobileNavLink>
              <Link
                href="https://t.me/Takeyoursoulgroup"
                className="px-6 py-3 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] rounded-md font-orbitron font-bold text-white hover:brightness-110 transition-all"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsMenuOpen(false)}
              >
                Join Telegram
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

interface NavLinkProps {
  href: string
  children: React.ReactNode
}

function NavLink({ href, children }: NavLinkProps) {
  return (
    <Link href={href} className="font-orbitron text-white hover:text-[#ff1744] transition-colors relative group">
      {children}
      <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#ff1744] group-hover:w-full transition-all duration-300"></span>
    </Link>
  )
}

interface MobileNavLinkProps {
  href: string
  children: React.ReactNode
  onClick: () => void
}

function MobileNavLink({ href, children, onClick }: MobileNavLinkProps) {
  return (
    <Link
      href={href}
      className="font-orbitron text-white text-2xl hover:text-[#ff1744] transition-colors"
      onClick={onClick}
    >
      {children}
    </Link>
  )
}
