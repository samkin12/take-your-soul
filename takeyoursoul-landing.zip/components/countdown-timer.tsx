"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface CountdownTimerProps {
  targetDate: string
  large?: boolean
}

export default function CountdownTimer({ targetDate, large = false }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = +new Date(targetDate) - +new Date()

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        })
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(timer)
  }, [targetDate])

  const containerClass = large
    ? "grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 max-w-3xl mx-auto"
    : "grid grid-cols-2 md:grid-cols-4 gap-3 max-w-xl mx-auto"

  const itemClass = large
    ? "bg-black/60 backdrop-blur-sm border border-white/10 rounded-lg p-6 flex flex-col items-center"
    : "bg-black/60 backdrop-blur-sm border border-white/10 rounded-lg p-4 flex flex-col items-center"

  const numberClass = large
    ? "text-4xl md:text-5xl font-orbitron font-bold text-white"
    : "text-2xl md:text-3xl font-orbitron font-bold text-white"

  const labelClass = large
    ? "text-sm uppercase tracking-wider text-gray-400 mt-2 font-space-mono"
    : "text-xs uppercase tracking-wider text-gray-400 mt-1 font-space-mono"

  return (
    <div className={containerClass}>
      <TimeUnit
        value={timeLeft.days}
        label="Days"
        itemClass={itemClass}
        numberClass={numberClass}
        labelClass={labelClass}
      />
      <TimeUnit
        value={timeLeft.hours}
        label="Hours"
        itemClass={itemClass}
        numberClass={numberClass}
        labelClass={labelClass}
      />
      <TimeUnit
        value={timeLeft.minutes}
        label="Minutes"
        itemClass={itemClass}
        numberClass={numberClass}
        labelClass={labelClass}
      />
      <TimeUnit
        value={timeLeft.seconds}
        label="Seconds"
        itemClass={itemClass}
        numberClass={numberClass}
        labelClass={labelClass}
      />
    </div>
  )
}

interface TimeUnitProps {
  value: number
  label: string
  itemClass: string
  numberClass: string
  labelClass: string
}

function TimeUnit({ value, label, itemClass, numberClass, labelClass }: TimeUnitProps) {
  return (
    <motion.div
      className={itemClass}
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.span
        key={value}
        className={numberClass}
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {value.toString().padStart(2, "0")}
      </motion.span>
      <span className={labelClass}>{label}</span>
    </motion.div>
  )
}
