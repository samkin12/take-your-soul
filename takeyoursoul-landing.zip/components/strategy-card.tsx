"use client"

import type React from "react"

import { motion } from "framer-motion"

interface StrategyCardProps {
  title: string
  description: string
  icon: React.ReactNode
  delay: number
}

export default function StrategyCard({ title, description, icon, delay }: StrategyCardProps) {
  return (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
      className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-6 relative overflow-hidden group"
    >
      <div className="absolute top-0 right-0 w-40 h-40 bg-[#7b1fa2] opacity-10 blur-[50px] rounded-full"></div>

      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#7b1fa2] to-[#ff1744] flex items-center justify-center flex-shrink-0">
          {icon}
        </div>

        <div>
          <h3 className="text-xl font-orbitron font-bold mb-2 text-white">{title}</h3>
          <p className="text-gray-300 font-space-mono text-sm">{description}</p>
        </div>
      </div>

      <div className="mt-4 w-full h-0.5 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
    </motion.div>
  )
}
