"use client"

import type React from "react"

import { motion } from "framer-motion"

interface TokenomicsCardProps {
  title: string
  description: string
  icon: React.ReactNode
  delay: number
}

export default function TokenomicsCard({ title, description, icon, delay }: TokenomicsCardProps) {
  return (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
      className="bg-black/40 backdrop-blur-sm border border-white/10 rounded-lg p-6 relative overflow-hidden group"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-[#7b1fa2]/10 to-[#ff1744]/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>

      <div className="relative z-10">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#7b1fa2] to-[#ff1744] flex items-center justify-center mb-4 mx-auto">
          {icon}
        </div>

        <h3 className="text-xl font-orbitron font-bold mb-2 text-white text-center">{title}</h3>
        <p className="text-gray-300 font-space-mono text-sm text-center">{description}</p>

        <div className="mt-4 w-full h-0.5 bg-gradient-to-r from-[#7b1fa2] to-[#ff1744] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
      </div>
    </motion.div>
  )
}
